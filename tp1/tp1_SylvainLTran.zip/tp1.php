<!--
    Auteur: Sylvain Tran
    But du programme: Générer des options select depuis un fichier dans le serveur.
    Date: 30-05-2020
-->
<html>
<head>
    <title>Travail Pratique #1</title>
    <meta charset="utf-8">
    <link rel="stylesheet" href="assets/css/main.css">
    <script src="assets/js/lib/jquery-3.5.1.min.js"></script>
    <script src="assets/js/main.js"></script>
</head>
<body>
    <h1>Informations m&eacute;t&eacute;orologiques</h1>
    <!-- Get the current time in the Montreal time zone, displayed in French -->
    <?php
        setlocale(LC_ALL, 'fr-CA');
        date_default_timezone_set('America/Montreal');
        echo "<h2 id=\"header__date\">".strftime('Le %A %e %B %Y - %T')."</h2>";    
    ?>
    <div id="main__selection">
        <label for="main__selection__city-list">Choix de la ville:</label>
        <select name="main__selection__city-list" id="main__selection__city-list" form="city-select-form">
        <!-- Fill the select options depending on the content of "villes.txt" -->
        <?php
            // Open the file at the specified path
            define("PATH", "villes.txt");
            if(!$fic=fopen(PATH, "r")) {
                echo "A problem occurred when trying to open 'villes.txt'.";                
                exit;
            }
            // Extract the city from each line
            $lineIterator=fgets($fic);
            // Delimiter is a single char ending with ';' and the other one at ':'
            $delimeter='/:{1}/'; 
            // Define constants for key:value for readability
            define("KEY", 0);
            define("VALUE", 1);            
            $options="";
            while (!feof($fic)) {
                // Split at the characters ; and an empty space (\s) as per the format '; ' on each line.
                $dataArray=preg_split('/;\s/',$lineIterator);
                // Split at the ':'
                $city=preg_split($delimeter,$dataArray[KEY]);
                $file=preg_split($delimeter,$dataArray[VALUE]);
                // Send both the city name and the file path in the value
                $option="<option value=".$city[VALUE].":".$file[VALUE].">".$city[VALUE]."</option>";
                $options.=$option;
                $lineIterator=fgets($fic);
            }
            fclose($fic);
            echo $options;
        ?>
        </select>
        <br><br>
        <!-- City select form (matched by id) -->
        <form id="city-select-form" action="assets/server/villes.php" method="POST">  
            <button id="button main__button--display-weather">Afficher la m&eacute;t&eacute;o</button>
        </form>   
        <br><br>
    </div>
    <hr class="hr--full-width">
    <p>
        Travail fait par: Sylvain Tran - p1195417. Login: transylv
    </p>
</body>
</html>