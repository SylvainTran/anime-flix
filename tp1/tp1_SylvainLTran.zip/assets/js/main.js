$(document).ready(setup);
// Submit the select form on click of the button
function setup() {
    $('#button main__button--display-weather').on("click", ()=> {
        $('#city-select-form').submit();
    });
}