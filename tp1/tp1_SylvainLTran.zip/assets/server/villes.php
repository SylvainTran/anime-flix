<!--
    Auteur: Sylvain Tran
    But du programme: Fournir, depuis un fichier correspondant a l'option selectionnée dans tp1.php, l'information
    météorologique de la ville.

    Date: 30-05-2020
-->
<html>
<head>
    <title>Travail Pratique #1</title>
    <link rel="stylesheet" href="../css/main.css">
</head>
<body>
    <h1>Informations m&eacute;t&eacute;orologiques</h1>
    <!-- Return a table with the meteorological info of the selected city in tp1.php -->
    <?php
        // Parse the city name in the value of the submitted form using the : delimiter
        // POST method version
        $selectedCity=strtok($_POST['main__selection__city-list'], ":");
        setlocale(LC_ALL, 'fr-CA');
        date_default_timezone_set('America/Montreal');
        echo "<h2 id=\"header__date\">".strftime('Le %A %e %B %Y - %T')."</h2>";    
        echo "<hr>";
        echo "<h3>Ville: ".$selectedCity."</h3>";
        define("DIR", "../data/");
        $selectedFilePath=$selectedCity;
        $selectedFilePath=strtok(":");
        define("PATH", DIR.$selectedFilePath);
        if(!$fic=fopen(PATH, "r")) {
            echo "X.txt has a problem with opening.";
            exit;
        }
        $deli=': ';
        // Cache the data so that we can valide if need be in the future. If NULL, do something else
        $information=NULL; // The first row's info (just the string)
        $temperature=NULL;
        $humidity=NULL;
        $wind=NULL;
        $desc=NULL; // The description in the last row
        // Define constants for key:value for readability
        define("KEY", 0);
        define("VALUE", 1);   

        $line=fgets($fic);                    
        while (! feof($fic)) {
            $data=explode($deli,$line);
            // This only works if the file is correctly formatted
            switch($data[KEY]) {
                case "information":
                    $information=$data[VALUE];
                    break;
                case "temperature":
                    $temperature=$data[VALUE];                
                    break;
                case "vent":
                    $wind=$data[VALUE];
                    break;
                case "humidite":
                    $humidity=$data[VALUE];
                    break;
                case "desc":
                    $desc=$data[VALUE];
                    break;                    
                default:
                    break;
            }
            $line=fgets($fic);
        }
        fclose($fic);

        // The dataTable and the headersTable follow each other in order
        $dataTable=array( $temperature, $humidity, $wind );
        $headersTable=array( "Temp&eacute;rature: ", "Humidit&eacute;: ", "Vent: " );
        $elements=count($dataTable);

        // Check for nulls in the information and desc vars, if null replace by &nbsp;
        if(is_null($information)) $information="&nbsp;";
        if(is_null($desc)) $desc="&nbsp;";

        // The echo indentation follows the html structure
        echo "<table id=\"main__table--weather-data\">";
            echo "<tr id=\"main__table--first-row\">";
                echo "<td colspan=\"3\">";
                echo "<img src=../img/".trim($information).".gif alt=image m&eacute;t&eacute;o></img><br>";
                echo $information;
                echo "</td>";
            echo "</tr>";
            echo "<tr>";
                for($i=0;$i<$elements;$i++) {
                    // Insert the header and data if it is not null; if null, insert &nbsp;
                    if(!is_null($dataTable[$i])) {
                        echo "<td>";
                        echo $headersTable[$i];
                        echo $dataTable[$i];
                        echo "</td>";
                    } else {
                        echo "<td>";
                        echo "&nbsp;";
                        echo "</td>";
                    }
                }
            echo "</tr>";
            echo "<tr id=\"main__table--last-row\">";
                echo "<td colspan=\"3\">".$desc."</td>";
            echo "</tr>";
        echo "</table>";            
    ?>
    <hr class="hr--full-width">
    <p>
        Travail fait par: Sylvain Tran - p1195417. Login: transylv
    </p>
</body>
</html>